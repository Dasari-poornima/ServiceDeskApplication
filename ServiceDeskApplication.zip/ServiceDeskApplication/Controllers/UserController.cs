using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using ServiceDeskApplication.Models;
using ServiceDeskApplication.Context;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;
using System.Net;
using System.Net.Mail;


namespace ServiceDeskApplication.Controllers
{
  public class UserController : Controller
  {
    // GET: User
    teamBEntities1 ent = new teamBEntities1();
    public ActionResult UserLandingpage()
    {
      return View();
    }
    [HttpGet]
    public ActionResult ViewProfile()
    {
      var viewpl = new List<ViewProfile>();
      var id = Convert.ToInt32(Session["ID"]);
      var viewprof = ent.sp_ViewProfile(id);
      ViewProfile vp = new ViewProfile();
      foreach (var item in viewprof)
      {

        vp.Emp_id = item.Emp_id;
        vp.Emp_name = item.Emp_name;
        vp.Email = item.Emp_email;
        vp.Emp_pw = item.Emp_pw;
        vp.Emp_Role = item.Emp_role;
        vp.Group_name = item.Grp_name;
        vp.Dept_name = item.Dept_name;
        viewpl.Add(vp);
      }
      return View(viewpl);
    }


    [HttpGet]
    public ActionResult Edit()
    {


      return View();
    }
    [HttpPost]
    public ActionResult Edit(UpdateProfile collection)
    {

      var id = Convert.ToInt32(Session["ID"]);
      int editprofile = ent.sp_UpdateProfile(id, collection.name, collection.email, collection.pw);
      ent.SaveChanges();
      ModelState.Clear();
      return View();
    }
    [HttpPost]
    public ActionResult CreateTicket(CreateTicket newticket)
    {

      if (ModelState.IsValid)
      {
        //var Tic_status = "Created";
        var user_id = Convert.ToInt32(Session["ID"]);
        //String user_name = (String)Session["name"];
        DateTime dtt = DateTime.Now;
        ent.sp_CreateTicket(newticket.Empemail, newticket.Deptname, newticket.Grpname, dtt, newticket.issue, user_id);
        ModelState.Clear();
        return View();

      }
      ModelState.Clear();
      return View();
    }

    public ActionResult MyTickets()
    {

      var mytickets = new List<MyTickets>();
      var id = Convert.ToInt32(Session["ID"]);
      var tik = ent.sp_ViewTickets(id);
      foreach (var item in tik)
      {
        MyTickets mt = new MyTickets();
        mt.Ticketid = item.Ticket_id;
        //Session["ticketid"]= item.Ticket_id;
        mt.Empemail = item.Emp_email;
        mt.Deptname = item.Dept_name;
        mt.Groupname = item.Grp_name;
        mt.Assignedto = item.Assigned_to;
        mt.Createddate = item.Created_date;
        mt.TStatus = item.TStatus;
        mt.Issue = item.Issue;
        mt.Empid = item.Emp_id;
        mytickets.Add(mt);
      }
      return View(mytickets);
    }
    public ActionResult EditTickets()
    {
      return View();
    }
    [HttpPost]
    public ActionResult EditTickets(UpdateTicket ut,int id)
    {
      var mytickets = new List<MyTickets>();
      //UpdateTicket ut = new UpdateTicket();
      //var ticketid = Convert.ToInt32(Session["ticketid"]);
      int editp = ent.sp_Updatetickets(ut.issue,id);
      ent.SaveChanges();
      ModelState.Clear();
      return View();
    }

    [HttpGet]
    public ActionResult AssignTickets()
    {

      var mytickets = new List<AssignedTickets>();
      var id = Convert.ToInt32(Session["ID"]);
      var ticket = ent.sp_AssignedTickets(id);
      foreach (var item in ticket)
      {
        AssignedTickets mt = new AssignedTickets();
        mt.Ticketid = item.Ticket_id;
        mt.Empemail = item.Emp_email;
        mt.Deptname = item.Dept_name;
        mt.Groupname = item.Grp_name;
        mt.Assignedto = item.Assigned_to;
        mt.Createddate = item.Created_date;
        mt.TStatus = item.TStatus;
        mt.Issue = item.Issue;
        mt.Empid = item.Emp_id;
        mytickets.Add(mt);
      }
      return View(mytickets);
    }
    [HttpGet]
    public ActionResult StatusUpdate()
    {

      return View();
    }
    [HttpPost]
    public ActionResult StatusUpdate(TicketStatusUpdate Sp, int id)
    {
     ent.sp_TicketStatusUpdate(id,Sp.Status);
     return View();
    }

    
    public ActionResult AddComment()
    {
      return View();
    }
    [HttpPost]
    public ActionResult AddComment(AddComments Sp, int id)
    {
      DateTime dt = DateTime.Now;
      //String name = (String)Session["name"];


      ent.sp_AddComments(id,dt,Sp.Updatedby, Sp.Comment,Sp.Updatedstatus);

      return View();
    }
    [HttpGet]
    public ActionResult ViewComments(int id)
    {
      var comm = new List<ViewComments>();
      var empid = Convert.ToInt32(Session["ID"]);
      var name = Convert.ToString(Session["name"]);
      var viewcomt = ent.sp_ViewComments(id);

      foreach (var item in viewcomt)
      {
        ViewComments vc = new ViewComments();
        vc.Msg_id = item.Msg_id;
        vc.Update_date = Convert.ToDateTime(item.Update_date);
        vc.Updated_by = (string)item.Updated_by;
        vc.Comment = item.Comment;
        vc.Updated_status = item.Updated_status;
       
        comm.Add(vc);

      }
      return View(comm);
    }
        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            return RedirectToAction("LoginAction", "Login");
        }



    public ActionResult sendmail()
    {
      return View();
    }
    [HttpPost]
    public ActionResult sendmail(ServiceDeskApplication.Models.MailModel _objModelMail)
    {
      if (ModelState.IsValid)
      {
        MailMessage mail = new MailMessage();
        mail.To.Add(_objModelMail.To);
        mail.From = new MailAddress(_objModelMail.From);
        mail.Subject = _objModelMail.Subject;
        string Body = _objModelMail.Body;
        mail.Body = Body;
        mail.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        smtp.Port = 587;
        smtp.UseDefaultCredentials = false;
        smtp.Credentials = new System.Net.NetworkCredential("poornima25d@gmail.com", "Gdeeksha@25"); // Enter seders User name and password   
        smtp.EnableSsl = true;
        smtp.Send(mail);
        ViewBag.Message = "Email sent.";
          return View("sendmail", _objModelMail);
      }
      else
      {
        return View();
      }

    }


  }
}
