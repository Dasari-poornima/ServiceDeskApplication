using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using ServiceDeskApplication.Models;
using ServiceDeskApplication.Context;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;
using System.Net;
using System.Net.Mail;



namespace ServiceDeskApplication.Controllers
{
    public class AdminController : UserController
    {
        // GET: Admin
        teamBEntities1 ent = new teamBEntities1();
        public ActionResult AdminLandingPage()
        {
            return View();
        }
        public ActionResult AllTickets()
        {
            var Dep = new List<DeptTickets>();
            //var id = Convert.ToInt32(Session["ID"]);
            var tik = ent.sp_AllTickets();
            foreach (var item in tik)
            {
                DeptTickets dept = new DeptTickets();
                dept.Ticketid = item.Ticket_id;
                dept.Empid = (int)item.Emp_id;
                dept.Email = item.Emp_email;
                dept.Deptname = item.Dept_name;
                dept.Grpname = item.Grp_name;
                dept.Assignedto = item.Assigned_to;
                dept.Createddate = item.Created_date;
                dept.Ticketstatus = item.TStatus;
                dept.Issue = item.Issue;

                Dep.Add(dept);
            }
            return View(Dep);
            //return View();
        }

       public ActionResult AdminAssignto(int id)
        {
            Session["Ticket_id"] = id;
            //Session["Dept_name"] = dn;
            //Session["Group_name"] = gn;
            return View();
        }
        [HttpPost]
        public ActionResult AdminAssignto(DeptTickets dept)
        {
            var id = Convert.ToInt32(Session["Ticket_id"]);
            //var dn = Convert.ToString(Session["Dept_name"]);
            //var gn = Convert.ToString(Session["Group_name"]);
            int assigntick = ent.sp_AssignTicketManager(dept.Empid, id);
            ent.SaveChanges();
            ModelState.Clear();
            return View();
        }
        public ActionResult ViewEmployees()
        {

            var vemp = new List<ViewEmp>();

            var ad = ent.sp_ViewEmployees();
            foreach (var item in ad)
            {
                ViewEmp aemp = new ViewEmp();
                aemp.EmployeeId = item.Emp_id;
                aemp.EmployeeName = item.Emp_name;
                aemp.EmployeeRole = item.Emp_role;
                aemp.EmployeeEmail = item.Emp_email;
                aemp.Password = item.Emp_pw;
                aemp.GroupName = item.Grp_name;
                aemp.LeadId = (int)item.Lead_id;
                aemp.ManagerId = (int)item.Mgr_id;
                aemp.DepartmentName = item.Dept_name;

                vemp.Add(aemp);
            }
            return View(vemp);

            
        }

        public ActionResult EditEmp(int id)
        {
            Session["empid"] = id; 
            return View();
        }

        // POST: Admin/Edit/5
        [HttpPost]
        public ActionResult EditEmp(ViewEmp collection)
        {

            var id = Convert.ToInt32(Session["empid"]);
            // TODO: Add update logic here
            int empedit = ent.sp_EditEmp(id, collection.EmployeeName, collection.EmployeeRole, collection.Password, collection.DepartmentName, collection.GroupName);
            ent.SaveChanges();
            ModelState.Clear();
            return View();
        }

        
        public ActionResult DeleteEmp(int id)
        {
            ent.sp_DeleteEmp(id);
            return View();
        }


    /*    [HttpPost]
        public ActionResult DeleteEmp()
        {
         // Session["empid"] = eid;
        //  var eid = Convert.ToInt32(Session["empid"]);
         
          return View();
         }*/

        public ActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddEmployee(ViewEmp emp)
        {
            ent.sp_AddEmployee(emp.EmployeeName,emp.EmployeeRole,emp.EmployeeEmail,emp.Password,emp.GroupName,emp.LeadId,emp.ManagerId,emp.DepartmentName);
            ModelState.Clear();
            TempData["notice1"] = "Employee added successfully";
            return View();
        }

    
  }
}
