using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using ServiceDeskApplication.Models;
using ServiceDeskApplication.Context;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;
using System.Net;
using System.Net.Mail;
using System.Linq;

namespace ServiceDeskApplication.Controllers
{
    public class LeadController : UserController
    {
        teamBEntities1 ent = new teamBEntities1();
        // GET: Lead
        public ActionResult LeadLandingPage()
        {
            return View();
        }
        [HttpGet]
        public ActionResult GroupTickets()
        {
            var Grp = new List<GroupTickets>();
            var grpname = Convert.ToString(Session["Grp_name"]);
            var tik = ent.sp_GroupTickets(grpname);
            foreach (var item in tik)
            {
                GroupTickets gt = new GroupTickets();
                gt.Ticketid = item.Ticket_id;
                gt.Empid = (int)item.Emp_id;
                gt.Email = item.Emp_email;
                gt.Deptname = item.Dept_name;
                gt.Grpname = item.Grp_name;
                gt.Assignedto = item.Assigned_to;
                gt.Createddate = item.Created_date;
                gt.Ticketstatus = item.TStatus;
                gt.Issue = item.Issue;

                Grp.Add(gt);
            }
            return View(Grp);
        }
        public ActionResult AssigntoEmpId(int id /*,string dn, string gn*/)
        {
            Session["Ticket_id"] = id;
            //Session["Dept_name"] = dn;
            //Session["Group_name"] = gn;
            return View();
        }
        [HttpPost]
        public ActionResult AssigntoEmpId(GroupTickets grp)
        {

            var id = Convert.ToInt32(Session["Ticket_id"]);
            //var dn = Convert.ToString(Session["Dept_name"]);
            //var gn = Convert.ToString(Session["Group_name"]);
            int assigntick = ent.sp_AssigntheTicket(grp.Empid,id);
            ent.SaveChanges();
            ModelState.Clear();
            return View();
        }
    


  }
}
