using ServiceDeskApplication.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceDeskApplication.Context;


namespace ServiceDeskApplication.Controllers
{
    public class LoginController : Controller
    {
    teamBEntities1 ent = new teamBEntities1();
        // GET: Login
        public ActionResult LoginAction()
       {
            return View();
        }
    [HttpPost]
    public ActionResult LoginAction(Login lgn)
    {
      if (ModelState.IsValid)
      {
        teamBEntities1 ent = new teamBEntities1();
        ObjectParameter name = new ObjectParameter("name", typeof(string));
        ObjectParameter isValid = new ObjectParameter("isValid", typeof(int));
        ObjectParameter Emppwd = new ObjectParameter("Pwd", typeof(String));
        ObjectParameter Grpname = new ObjectParameter("Grpname", typeof(String));
        ObjectParameter Deptname = new ObjectParameter("Deptname", typeof(String));
        ObjectParameter empid = new ObjectParameter("Id", typeof(int));
        
        
       

        var value = ent.sp_Login(lgn.username, lgn.password, isValid,empid,name,Deptname, Grpname);


       ViewBag.vb = Convert.ToInt32(isValid.Value);

       
                
        if (ViewBag.vb == 4)
        {
          Session["ID"] = Convert.ToInt32(empid.Value);
          Session["Grp_name"] = Convert.ToString(Grpname.Value);
          Session["Dept_name"] = Convert.ToString(Deptname.Value);
          Session["name"] = Convert.ToString(name.Value);
          //Session["isValid"] = Convert.ToInt32(isValid.Value);
          Session["Password"] = Convert.ToString(Emppwd.Value);
          return View("../User/UserLandingpage");
        }
        else if (ViewBag.vb == 3)
        {
          Session["ID"] = Convert.ToInt32(empid.Value);
          Session["name"] = Convert.ToString(name.Value);
          //Session["isValid"] = Convert.ToInt32(isValid.Value);
          Session["Password"] = Convert.ToString(Emppwd.Value);
          Session["Grp_name"] = Convert.ToString(Grpname.Value);
          Session["Dept_name"] = Convert.ToString(Deptname.Value);


          return View("../Lead/LeadLandingPage");


        }
        else if (ViewBag.vb == 2)
        {
          Session["ID"] = Convert.ToInt32(empid.Value);
          Session["name"] = Convert.ToString(name.Value);
          //Session["isValid"] = Convert.ToInt32(isValid.Value);
          Session["Password"] = Convert.ToString(Emppwd.Value);
          Session["Grp_name"] = Convert.ToString(Grpname.Value);
          Session["Dept_name"] = Convert.ToString(Deptname.Value);
          return View("../Manager/ManagerLandingPage");

        }
        else if (ViewBag.vb == 1)
        {
          Session["ID"] = Convert.ToInt32(empid.Value);
          Session["name"] = Convert.ToString(name.Value);
          //Session["isValid"] = Convert.ToInt32(isValid.Value);
          Session["Password"] = Convert.ToString(Emppwd.Value);
          Session["Grp_name"] = Convert.ToString(Grpname.Value);
          Session["Dept_name"] = Convert.ToString(Deptname.Value);
          return View("../Admin/AdminLandingPage");
        }


        else if(ViewBag.vb == 5)
        {
          ModelState.Clear();
          ModelState.AddModelError("", "InValid Credentials");
          return View("LoginAction");
        }
        

      }
      ModelState.AddModelError("", "InValid Credentials");

      return View("LoginAction");
    }

  }
}
