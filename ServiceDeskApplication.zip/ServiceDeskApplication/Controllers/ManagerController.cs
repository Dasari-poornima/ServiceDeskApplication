using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using ServiceDeskApplication.Models;
using ServiceDeskApplication.Context;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;
using System.Net;
using System.Net.Mail;
using System.Linq;

namespace ServiceDeskApplication.Controllers
{
    public class ManagerController : UserController
    {
        teamBEntities1 ent = new teamBEntities1();
        // GET: Manager
        public ActionResult ManagerLandingPage()
        {
            return View();
        }
        public ActionResult DeptTickets()
        {
            var Dep = new List<DeptTickets>();
            var Deptname = Convert.ToString(Session["Dept_name"]);
            var tik = ent.sp_DeptTickets(Deptname);
            foreach (var item in tik)
            {
                DeptTickets dept = new DeptTickets();
                dept.Ticketid = item.Ticket_id;
                dept.Empid = (int)item.Emp_id;
                dept.Email = item.Emp_email;
                dept.Deptname = item.Dept_name;
                dept.Grpname = item.Grp_name;
                dept.Assignedto = item.Assigned_to;
                dept.Createddate = item.Created_date;
                dept.Ticketstatus = item.TStatus;
                dept.Issue = item.Issue;

                Dep.Add(dept);
            }
            return View(Dep);

        }
        public ActionResult Assigntomanager(int id /*,string dn, string gn*/)
        {
            Session["Ticket_id"] = id;
            //Session["Dept_name"] = dn;
            //Session["Group_name"] = gn;
            return View();
        }
        [HttpPost]
        public ActionResult Assigntomanager(DeptTickets dept)
        {
            var id = Convert.ToInt32(Session["Ticket_id"]);
            //var dn = Convert.ToString(Session["Dept_name"]);
            //var gn = Convert.ToString(Session["Group_name"]);
            int assigntick = ent.sp_AssignTicketManager(dept.Empid, id);
            ent.SaveChanges();
            ModelState.Clear();
            return View();
        }

    }
  }

