using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceDeskApplication.Models
{
  public class CreateTicket
  {
    
    public string Empemail { get; set; }
    public string Deptname { get; set; }

    public string Grpname { get; set; }
    public string Createddate { get; set; }
    
    
    public string issue { get; set; }

    public int Empid { get; set; }
  }
}
