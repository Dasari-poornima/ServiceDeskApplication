using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ServiceDeskApplication.Models
{
  public class MyTickets
  {
    [Key]
    public int Ticketid { get; set; }

    public string Empemail { get; set; }

    public string Deptname { get; set; }
    public string Groupname { get; set; }

    public Nullable<int> Assignedto { get; set; }

    public Nullable<DateTime> Createddate { get; set; }

    public string TStatus { get; set; }

    public string Issue { get; set; }
    public Nullable<int> Empid { get; set; }
    
  }
}
