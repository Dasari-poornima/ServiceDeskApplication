﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ServiceDeskApplication.Models
{
   
    public class DeptTickets
    {
        [Key]
        public int Ticketid { get; set; }
        public int Empid { get; set; }
        public string Email { get; set; }
        public string Deptname { get; set; }
        public string Grpname { get; set; }
        public Nullable<int> Assignedto { get; set; }

        public Nullable<DateTime> Createddate { get; set; }
        public string Ticketstatus { get; set; }
        public string Issue { get; set; }

    }
}