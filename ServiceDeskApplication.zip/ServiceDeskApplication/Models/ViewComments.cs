using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ServiceDeskApplication.Models
{
  public class ViewComments
  {
    [Key]
    public int Ticketid { get; set; }

    public int Msg_id { get; set; }
    public DateTime Update_date { get; set; }
    public string Updated_by { get; set; }
    public string Comment { get; set; }

    public string Updated_status { get; set; }


  }
}
