using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceDeskApplication.Models
{
  public class UpdateProfile
  {
    public int empid { get; set; }
    public string name { get; set; }

    public string email { get; set; }

    public string pw { get; set; }

  }
}
