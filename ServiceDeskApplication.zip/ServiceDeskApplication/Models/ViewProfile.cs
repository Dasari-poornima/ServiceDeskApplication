using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ServiceDeskApplication.Models
{
  public class ViewProfile
  {
    [Key]
    public int Emp_id { get; set; }
    public string Emp_name { get; set; }

    public string Emp_Role { get; set; }
    public string Email { get; set; }
    public string Emp_pw { get; set; }
    
    
    public string Dept_name { get; set; }
    public string Group_name { get; set; }
  }
}
