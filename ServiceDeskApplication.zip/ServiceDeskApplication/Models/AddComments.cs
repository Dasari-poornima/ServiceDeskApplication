using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ServiceDeskApplication.Models
{
  public class AddComments
  {
    [Key]
    public int Ticketid { get; set; }
    
    //public DateTime Updateddate { get; set; }
    public string Updatedby { get; set; }
    public string Comment { get; set; }

    public string Updatedstatus { get; set; }

    


    
  }
}
