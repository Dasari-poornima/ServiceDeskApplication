using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ServiceDeskApplication.Models
{
  public class UpdateTicket
  {
    [Key]
    public int ticketid { get; set; }

    public string issue { get; set; }

  }
}
