using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace ServiceDeskApplication.Models
{
  public class User
  {
    public int Emp_id { get; set; }

    public string emprole { get; set; }

    public string Empemail { get; set; }
    public string Deptname { get; set; }

    public string Grpname { get; set; }
    
    public string Issue { get; set; }
    public int ass_to { get; set; }
  }
}
