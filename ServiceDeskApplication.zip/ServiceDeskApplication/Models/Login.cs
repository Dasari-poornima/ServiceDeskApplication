using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace ServiceDeskApplication.Models
{
  public class Login
  {
    [Key]
    [Required(ErrorMessage = "EmployeeName is required")]
    public string username { get; set; }
    [Required(ErrorMessage = "Password is required")]
    [DataType(DataType.Password)]
    public string password { get; set; }
    public int isValid { get; set; }

    //public int empid { get; set; }


  }
}
